package com.badlogic.drop;

import java.util.Iterator;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

public class GameScreen implements Screen {
    final Tankstars game;


    Texture t1Image;
    Texture t2Image;
    Texture RocketImage;
    Texture RocketImage2;
    private Texture BACKGROUNDdImage;
    private TextureRegion BACKGROUNDdTexture;

    Music musicMusic;
    OrthographicCamera camera;
    Rectangle t1;
    Rectangle t2;
    int h1=100;
    int h2=100;
    Array<Rectangle> Rockets;
    Array<Rectangle> Rockets2;
    long lastDropTime;
    int dropsGathered;


    public GameScreen(final Tankstars game) {
        this.game = game;

        RocketImage=new Texture(Gdx.files.internal("r1.jpeg"));
        RocketImage2=new Texture(Gdx.files.internal("r2.jpeg"));
        t1Image = new Texture(Gdx.files.internal("tank1.png"));
        t2Image = new Texture(Gdx.files.internal("tank2.png"));
        BACKGROUNDdImage = new Texture(Gdx.files.internal("BACKGROUND.jpg"));
        BACKGROUNDdTexture = new TextureRegion(BACKGROUNDdImage, 0, 0, 1920, 1439);



        musicMusic = Gdx.audio.newMusic(Gdx.files.internal("music.mp3"));
        musicMusic.setLooping(true);


        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);

        t1 = new Rectangle();
        t1.x = 0;
        t1.y = 205;

        t1.width = 120;
        t1.height = 90;


        t2 = new Rectangle();
        t2.x = 800;
        t2.y = 125;

        t2.width = 120;
        t2.height = 90;

        Rockets = new Array<Rectangle>();
        spawnRocket();
        Rockets2 = new Array<Rectangle>();
        spawnRocket2();

    }
    private void spawnRocket() {
        Rectangle fire = new Rectangle();
        fire.x = t1.x+80;
        fire.y = t1.y+120;
        fire.width = 30;
        fire.height = 30;
        Rockets.add(fire);
        long now1=TimeUtils.nanoTime();
        lastDropTime =TimeUtils.nanosToMillis(now1);
    }
    private void spawnRocket2() {
        Rectangle fire = new Rectangle();
        fire.x = t2.x+80;
        fire.y = t2.y+120;
        fire.width = 30;
        fire.height = 30;
        Rockets.add(fire);
        long now1=TimeUtils.nanoTime();
        lastDropTime =TimeUtils.nanosToMillis(now1);
    }




    @Override
    public void render(float delta) {

        ScreenUtils.clear(0, 0, 0.2f, 1);


        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();
        game.batch.draw(BACKGROUNDdTexture, 0,0, 800, 480);

        game.batch.draw(t1Image, t1.x, t1.y, t1.width, t1.height);
        game.batch.draw(t2Image, t2.x, t2.y, t2.width, t2.height);
        game.font.draw(game.batch, "Click P to Pause", 10, 460);
        game.font.draw(game.batch, "Click Q to fire from tank1", 10, 420);
        game.font.draw(game.batch, "Click L to fire from tank2", 700, 420);
        game.font.draw(game.batch, "Health =  "+h1, 10, 420);
        game.font.draw(game.batch, "Health ="+h2, 700, 420);
        for (Rectangle fire : Rockets) {
            game.batch.draw(RocketImage, fire.x, fire.y);
        }
        for (Rectangle fire  :Rockets2) {
            game.batch.draw(RocketImage2, fire.x, fire.y);
        }
        game.batch.end();


        if(Gdx.input.isKeyPressed(Keys.P)){
            game.setScreen(new ResumeScreen(game));
            dispose();
        }
        if (Gdx.input.isKeyPressed(Keys.LEFT))
            t1.x -= 200 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.RIGHT))
            t1.x += 200 * Gdx.graphics.getDeltaTime();


        if (Gdx.input.isKeyPressed(Keys.UP))
            t2.x -= 200 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.DOWN))
            t2.x += 200 * Gdx.graphics.getDeltaTime();


        if (t1.x < 0)
           t1.x = 0;
        if (t1.x > 800 - 120)
            t1.x = 800 - 120;


        if (t2.x < 0)
            t2.x = 0;
        if (t2.x > 800 - 120)
            t2.x = 800 - 120;

        if(t1.x> 0 && t1.x <= 30){
            t1.y = 205;
        }
        if(t1.x > 30 && t1.x >= 90){
            t1.y = 190;
        }
        if(t1.x > 90 && t1.x >= 110){
            t1.y = 180;
        }
        if(t1.x > 110 && t1.x >= 120){
            t1.y = 170;
        }
        if(t1.x > 120 && t1.x >= 130){
            t1.y = 160;
        }
        if(t1.x > 130 && t1.x >= 140){
            t1.y = 150;
        }
        if(t1.x > 140 && t1.x >= 145){
            t1.y = 147;
        }
        if(t1.x > 145 && t1.x >= 150){
            t1.y = 145;
        }
        if(t1.x > 150 && t1.x >= 160){
            t1.y = 140;
        }
        if(t1.x > 160 && t1.x >= 170){
            t1.y = 130;
        }
        if(t1.x > 170 && t1.x >= 180){
            t1.y = 125;
        }
        if(t1.x > 180 && t1.x >= 190){
            t1.y = 117;
        }
        if(t1.x > 190 && t1.x >= 200){
            t1.y = 110;
        }
        if(t1.x > 200 && t1.x >= 210){
            t1.y = 105;
        }
        if(t1.x > 210 && t1.x >= 220){
            t1.y = 98;
        }
        if(t1.x > 220 && t1.x >= 230){
            t1.y = 96;
        }
        if(t1.x > 230 && t1.x >= 240){
            t1.y = 92;
        }
        if(t1.x > 240 && t1.x >= 250){
            t1.y = 89;
        }
        if(t1.x > 250 && t1.x >= 260){
            t1.y = 86;
        }
        if(t1.x > 260 && t1.x >= 270){
            t1.y = 85;
        }
        if(t1.x > 270 && t1.x >= 280){
            t1.y = 80;
        }
        if(t1.x > 280 && t1.x >= 290){
            t1.y = 75;
        }
        if(t1.x > 290 && t1.x >= 300){
            t1.y = 70;
        }
        if(t1.x > 300 && t1.x >= 310){
            t1.y = 75;
        }
        if(t1.x > 310 && t1.x >= 313){
            t1.y = 73;
        }
        if(t1.x > 313 && t1.x >= 319){
            t1.y = 70;
        }
        if(t1.x > 313 && t1.x >= 319){
            t1.y = 70;
        }
        if(t1.x > 319 && t1.x >= 327){
            t1.y = 65;
        }
        if(t1.x > 327 && t1.x >= 335){
            t1.y = 63;
        }
        if(t1.x > 335 && t1.x >= 340){
            t1.y = 61;
        }
        if(t1.x > 340 && t1.x >= 345){
            t1.y = 63;
        }
        if(t1.x > 345 && t1.x >= 350){
            t1.y = 60;
        }
        if(t1.x > 350 && t1.x >=360){
            t1.y = 56;
        }
        if(t1.x > 360 && t1.x >=370){
            t1.y =50;
        }
        if(t1.x > 370 && t1.x >= 380){
            t1.y =55;
        }
        if(t1.x > 380 && t1.x >= 390){
            t1.y =60;
        }
        if(t1.x > 390 && t1.x >= 400){
            t1.y =65;
        }
        if(t1.x > 410 && t1.x >= 420){
            t1.y =68;
        }
        if(t1.x > 420 && t1.x >= 440){
            t1.y =74;
        }
        if(t1.x > 440 && t1.x >= 450){
            t1.y =78;
        }
        if(t1.x > 460 && t1.x >= 475){
            t1.y =85;
        }
        if(t1.x > 475 && t1.x >= 485){
            t1.y = 89;
        }
        if(t1.x > 485 && t1.x >= 495){
            t1.y = 92;
        }
        if(t1.x > 495 && t1.x >= 510){
            t1.y = 94;
        }
        if(t1.x > 510 && t1.x >= 520){
            t1.y = 99;
        }
        if(t1.x > 520 && t1.x >= 535){
            t1.y = 104;
        }
        if(t1.x > 535 && t1.x >= 550){
            t1.y = 109;
        }
        if(t1.x > 550 && t1.x >= 560){
            t1.y = 113;
        }
        if(t1.x > 560){
            t1.y = 116;
        }
        if( t2.x >= 555  && t2.x <560){
            t2.y = 116;
        }
        if( t2.x >= 550  && t2.x <555){
            t2.y = 113;
        }
        if( t2.x >= 540   && t2.x <550){
            t2.y = 105;
        }
        if( t2.x >= 520   && t2.x <540){
            t2.y = 96;
        }
        if( t2.x >= 500   && t2.x <520){
            t2.y = 90;
        }
        if( t2.x >= 480   && t2.x <500){
            t2.y = 90;
        }
        if( t2.x >= 460   && t2.x <480){
            t2.y = 80;
        }
        if( t2.x >= 440   && t2.x <460){
            t2.y = 70;
        }
        if( t2.x >= 420   && t2.x <440){
            t2.y = 60;
        }
        if( t2.x >= 400   && t2.x <420){
            t2.y = 50;
        }
        if( t2.x >= 380   && t2.x <400){
            t2.y = 47;
        }
        if( t2.x >= 340   && t2.x <380){
            t2.y = 50;
        }
        if( t2.x >= 320  && t2.x <340){
            t2.y = 60;
        }
        if( t2.x >= 300  && t2.x <320){
            t2.y = 68;
        }


        if(t2.x> 0 && t2.x <= 30){
            t2.y = 205;
        }
        if(t2.x > 30 && t2.x >= 90){
            t2.y = 190;
        }
        if(t2.x > 90 && t2.x >= 110){
            t2.y = 180;
        }
        if(t2.x > 110 && t2.x >= 120){
            t2.y = 170;
        }
        if(t2.x > 120 && t2.x >= 130){
            t2.y = 160;
        }
        if(t2.x > 130 && t2.x >= 140){
            t2.y = 150;
        }
        if(t2.x > 140 && t2.x >= 145){
            t2.y = 147;
        }
        if(t2.x > 145 && t2.x >= 150){
            t2.y = 145;
        }
        if(t2.x > 150 && t2.x >= 160){
            t2.y = 140;
        }
        if(t2.x > 160 && t2.x >= 170){
            t2.y = 130;
        }
        if(t2.x > 170 && t2.x >= 180){
            t2.y = 125;
        }
        if(t2.x > 180 && t2.x >= 190){
            t2.y = 117;
        }
        if(t2.x > 190 && t2.x >= 200){
            t2.y = 110;
        }
        if(t2.x > 200 && t2.x >= 210){
            t2.y = 105;
        }
        if(t2.x > 210 && t2.x >= 220){
            t2.y = 98;
        }
        if(t2.x > 220 && t2.x >= 230){
            t2.y = 96;
        }
        if(t2.x > 230 && t2.x >= 240){
            t2.y = 92;
        }
        if(t2.x > 240 && t2.x >= 250){
            t2.y = 89;
        }
        if(t2.x > 250 && t2.x >= 260){
            t2.y = 86;
        }
        if(t2.x > 260 && t2.x >= 270){
            t2.y = 85;
        }
        if(t2.x > 270 && t2.x >= 280){
            t2.y = 80;
        }
        if(t2.x > 280 && t2.x >= 290){
            t2.y = 75;
        }
        if(t2.x > 290 && t2.x >= 300){
            t2.y = 70;
        }
        if(t2.x > 300 && t2.x >= 310){
            t2.y = 75;
        }
        if(t2.x > 310 && t2.x >= 313){
            t2.y = 73;
        }
        if(t2.x > 313 && t2.x >= 319){
            t2.y = 70;
        }
        if(t2.x > 313 && t2.x >= 319){
            t2.y = 70;
        }
        if(t2.x > 319 && t2.x >= 327){
            t2.y = 65;
        }
        if(t2.x > 327 && t2.x >= 335){
            t2.y = 63;
        }
        if(t2.x > 335 && t2.x >= 340){
            t2.y = 61;
        }
        if(t2.x > 340 && t2.x >= 345){
            t2.y = 63;
        }
        if(t2.x > 345 && t2.x >= 350){
            t2.y = 60;
        }
        if(t2.x > 350 && t2.x >=360){
            t2.y = 56;
        }
        if(t2.x > 360 && t2.x >=370){
            t2.y =50;
        }
        if(t2.x > 370 && t2.x >= 380){
            t2.y =55;
        }
        if(t2.x > 380 && t2.x >= 390){
            t2.y =60;
        }
        if(t2.x > 390 && t2.x >= 400){
            t2.y =65;
        }
        if(t2.x > 410 && t2.x >= 420){
            t2.y =68;
        }
        if(t2.x > 420 && t2.x >= 440){
            t2.y =74;
        }
        if(t2.x > 440 && t2.x >= 450){
            t2.y =78;
        }
        if(t2.x > 460 && t2.x >= 475){
            t2.y =85;
        }
        if(t2.x > 475 && t2.x >= 485){
            t2.y = 89;
        }
        if(t2.x > 485 && t2.x >= 495){
            t2.y = 92;
        }
        if(t2.x > 495 && t2.x >= 510){
            t2.y = 94;
        }
        if(t2.x > 510 && t2.x >= 520){
            t2.y = 99;
        }
        if(t2.x > 520 && t2.x >= 535){
            t2.y = 104;
        }
        if(t2.x > 535 && t2.x >= 550){
            t2.y = 109;
        }
        if(t2.x > 550 && t2.x >= 560){
            t2.y = 113;
        }
        if(t2.x > 560){
            t2.y = 116;
        }


        if (Gdx.input.isKeyPressed(Keys.Q))
            spawnRocket();

        Iterator<Rectangle> iterat = Rockets.iterator();

        while (iterat.hasNext()) {
            Rectangle fire = iterat.next();

            fire.x += 50 * (Gdx.graphics.getDeltaTime()+0.01);
            if(fire.x<=400 && fire.y<=480){

                fire.y+=(50/(1.732))*(Gdx.graphics.getDeltaTime()+0.01);

            }

            if((fire.x>=400 && fire.y>=0)||(fire.y>=480) ){

                fire.y-=(50*(1.5)*(Gdx.graphics.getDeltaTime()+0.01));

            }

            if (fire.x + 10 >800)
                iterat.remove();
            if (fire.overlaps(t2)) {
                h2=h2-5;
                iterat.remove();
            }}



        if (Gdx.input.isKeyPressed(Keys.L))
            spawnRocket2();

        Iterator<Rectangle> iter2 =Rockets2.iterator();

        while (iterat.hasNext()) {
            Rectangle fire = iterat.next();

            fire.x -= 50 * (Gdx.graphics.getDeltaTime()+0.01);
            if(fire.x>=400 && fire.y<=480){

                fire.y+=(50*(1.5))*(Gdx.graphics.getDeltaTime()+0.01);

                fire.y+=(50*(1.732))*(Gdx.graphics.getDeltaTime()+0.01);

            }

            if((fire.x<=400 && fire.y>=0)||(fire.y>=480) ){

                fire.y-=(50/(1.732))*(Gdx.graphics.getDeltaTime()+0.01);

            }

            if (fire.x + 10 >800)
                iterat.remove();
            if (fire.overlaps(t2)) {
                h2=h2-5;
                iterat.remove();
            }}






    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
        musicMusic.play();
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {

        RocketImage.dispose();
        RocketImage2.dispose();
        t1Image.dispose();
        t2Image.dispose();
        musicMusic.dispose();
    }

}

package com.badlogic.drop;

import java.io.Serializable;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;
public class ResumeScreen implements Screen,Serializable {

    final Tankstars game;
    private Texture BACKGROUNDdImage;
    private TextureRegion BACKGROUNDdTexture;
    OrthographicCamera camera;

    public ResumeScreen(final Tankstars game) {
        this.game = game;
        BACKGROUNDdImage = new Texture(Gdx.files.internal("Background.jpeg"));
        BACKGROUNDdTexture = new TextureRegion(BACKGROUNDdImage, 0, 0, 600, 336);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(BACKGROUNDdTexture, 0,0, 800, 480);
        game.font.draw(game.batch, "Click R to Resume", 300, 240);
        game.font.draw(game.batch, "Click N to start a New Game", 300, 270);
        game.font.draw(game.batch, "Click E to Exit", 300, 210);
        //game.font.draw(game.batch, "Click anywhere to begin!", 300, 140);
        game.batch.end();

        if (Gdx.input.isTouched()) {
            game.setScreen(new GameScreen(game));
            dispose();
        }
        if(Gdx.input.isKeyPressed(Input.Keys.R)){
            game.setScreen(new GameScreen(game));
            dispose();
        }
        if(Gdx.input.isKeyPressed(Input.Keys.N)){
            game.setScreen(new GameMainMenu(game));
            dispose();
        }
        if(Gdx.input.isKeyPressed(Input.Keys.E)){
            game.setScreen(new Exit(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
